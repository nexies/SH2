#include "SqlValue.h"

SqlValue::SqlValue() :
    _length { -1 }
{

}
